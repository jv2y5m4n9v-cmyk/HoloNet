import {exec} from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import {describe, expect, it, vi} from "vitest";
import {stringify} from "../lib/util/stringify";
import utils, {assertString} from "../lib/util/utils";

// keep the implementations, just spy
vi.mock("node:child_process", {spy: true});

describe("Utils", () => {
    it("Object is empty", () => {
        expect(utils.objectIsEmpty({})).toBeTruthy();
        expect(utils.objectIsEmpty({a: 1})).toBeFalsy();
    });

    it("Object has properties", () => {
        expect(utils.objectHasProperties({a: 1, b: 2, c: 3}, ["a", "b"])).toBeTruthy();
        expect(utils.objectHasProperties({a: 1, b: 2, c: 3}, ["a", "b", "d"])).toBeFalsy();
    });

    it("get Z2M version", async () => {
        const readFileSyncSpy = vi.spyOn(fs, "readFileSync");
        const version = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "package.json"), "utf8")).version;

        expect(await utils.getZigbee2MQTTVersion()).toStrictEqual({commitHash: expect.stringMatching(/^(?!unknown)[a-z0-9]{8}$/), version});
        expect(exec).toHaveBeenCalledTimes(1);

        // @ts-expect-error mock spy
        exec.mockImplementationOnce((_cmd, cb) => {
            cb(null, "abcd1234");
        });
        expect(await utils.getZigbee2MQTTVersion()).toStrictEqual({commitHash: "abcd1234", version});

        // @ts-expect-error mock spy
        exec.mockImplementationOnce((_cmd, cb) => {
            cb(null, "");
        });
        // hash file may or may not be present during testing, don't failing matching if not
        expect(await utils.getZigbee2MQTTVersion()).toStrictEqual({commitHash: expect.stringMatching(/^(unknown|([a-z0-9]{8}))$/), version});

        readFileSyncSpy.mockImplementationOnce(() => {
            throw new Error("no hash file");
        });
        // @ts-expect-error mock spy
        exec.mockImplementationOnce((_cmd, cb) => {
            cb(null, "");
        });
        expect(await utils.getZigbee2MQTTVersion()).toStrictEqual({commitHash: "unknown", version});

        readFileSyncSpy.mockImplementationOnce(() => {
            throw new Error("no hash file");
        });
        // @ts-expect-error mock spy
        exec.mockImplementationOnce((_cmd, cb) => {
            cb(new Error("invalid"), "");
        });
        expect(await utils.getZigbee2MQTTVersion()).toStrictEqual({commitHash: "unknown", version});
        expect(exec).toHaveBeenCalledTimes(5);
    });

    it("Check dependency version", async () => {
        const versionHerdsman = JSON.parse(
            fs.readFileSync(path.join(__dirname, "..", "node_modules", "zigbee-herdsman", "package.json"), "utf8"),
        ).version;
        const versionHerdsmanConverters = JSON.parse(
            fs.readFileSync(path.join(__dirname, "..", "node_modules", "zigbee-herdsman-converters", "package.json"), "utf8"),
        ).version;
        expect(await utils.getDependencyVersion("zigbee-herdsman")).toStrictEqual({version: versionHerdsman});
        expect(await utils.getDependencyVersion("zigbee-herdsman-converters")).toStrictEqual({version: versionHerdsmanConverters});
    });

    it("To local iso string", () => {
        const date = new Date("August 19, 1975 23:15:30 UTC+00:00").getTime();
        const getTzOffsetSpy = vi.spyOn(Date.prototype, "getTimezoneOffset");
        getTzOffsetSpy.mockReturnValueOnce(60);
        expect(utils.formatDate(date, "ISO_8601_local").toString().endsWith("-01:00")).toBeTruthy();
        getTzOffsetSpy.mockReturnValueOnce(-60);
        expect(utils.formatDate(date, "ISO_8601_local").toString().endsWith("+01:00")).toBeTruthy();
    });

    it("Assert string", () => {
        assertString("test", "property");
        expect(() => assertString(1, "property")).toThrow("property is not a string, got number (1)");
    });

    it("Removes null properties from object", () => {
        const obj1 = {
            ab: 0,
            cd: false,
            ef: null,
            gh: "",
            homeassistant: {
                xyz: "mock",
                abcd: null,
            },
            nested: {
                homeassistant: {
                    abcd: true,
                    xyz: null,
                },
                abc: {},
                def: null,
            },
        };

        utils.removeNullPropertiesFromObject(obj1);
        expect(obj1).toStrictEqual({
            ab: 0,
            cd: false,
            gh: "",
            homeassistant: {
                xyz: "mock",
            },
            nested: {
                homeassistant: {
                    abcd: true,
                },
                abc: {},
            },
        });

        const obj2 = {
            ab: 0,
            cd: false,
            ef: null,
            gh: "",
            homeassistant: {
                xyz: "mock",
                abcd: null,
            },
            nested: {
                homeassistant: {
                    abcd: true,
                    xyz: null,
                },
                abc: {},
                def: null,
            },
        };
        utils.removeNullPropertiesFromObject(obj2, ["homeassistant"]);
        expect(obj2).toStrictEqual({
            ab: 0,
            cd: false,
            gh: "",
            homeassistant: {
                xyz: "mock",
                abcd: null,
            },
            nested: {
                homeassistant: {
                    abcd: true,
                    xyz: null,
                },
                abc: {},
            },
        });
    });

    it("stable stringify", () => {
        expect(
            stringify({
                a: "a",
                b: 2,
                3: "c",
                d: Buffer.from([1, 2]),
                e: new Int16Array([0xfffd, 0xff11, 0x0001, 0x7fff]),
                beef: 0xfacen,
                zed: new BigUint64Array([1n, 0xffffffffn, 42n]),
                ris: [1, undefined, "b", 0xfeefn, Number.NaN, undefined],
                ls: undefined,
                // one and two elements, on both the number and the bigint branch
                one: new Uint8Array([7]),
                two: new Int16Array([0x0001, 0x7fff]),
                oneBig: new BigInt64Array([-9n]),
                twoBig: new BigUint64Array([1n, 42n]),
            }),
        ).toStrictEqual(
            `{"3":"c","a":"a","b":2,"beef":"64206","d":{"data":[1,2],"type":"Buffer"},"e":{"0":-3,"1":-239,"2":1,"3":32767},"one":{"0":7},"oneBig":{"0":"-9"},"ris":[1,null,"b","65263",null,null],"two":{"0":1,"1":32767},"twoBig":{"0":"1","1":"42"},"zed":{"0":"1","1":"4294967295","2":"42"}}`,
        );
        // @ts-expect-error intentional to reach code for coverage
        expect(stringify(undefined)).toStrictEqual("null");

        const circularObj: Record<string, unknown> = {a: 1, b: undefined};
        circularObj.b = circularObj;

        expect(stringify(circularObj)).toStrictEqual(`{"a":1,"b":"[Circular]"}`);

        const toJSONIsString = {a: 1, toJSON: () => `{"a":1}`};

        expect(stringify(toJSONIsString)).toStrictEqual(`"{\\"a\\":1}"`);

        const toJSONIsNull = {a: 1, toJSON: () => null};

        expect(stringify(toJSONIsNull)).toStrictEqual("null");

        const emptyTypedArrayWithProperty = Object.assign(new Uint8Array(0), {unit: "raw"});

        expect(stringify({data: emptyTypedArrayWithProperty})).toStrictEqual(JSON.stringify({data: {unit: "raw"}}));
        expect(stringify({data: new Uint8Array(0)})).toStrictEqual(JSON.stringify({data: {}}));
    });
});
